// type script: interface means that the object is of type this (user)
export interface User{
username : string;
token: string;
}
